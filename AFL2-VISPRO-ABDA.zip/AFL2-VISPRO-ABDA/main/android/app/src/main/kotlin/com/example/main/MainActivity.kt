package com.example.main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
